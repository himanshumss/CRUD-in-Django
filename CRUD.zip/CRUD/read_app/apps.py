from django.apps import AppConfig


class ReadAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "read_app"
